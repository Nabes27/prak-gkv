#include <GL/glut.h>
#include <stdlib.h>

// Variabel untuk rotasi
float rotAngle = 0.0f;
float rotAngle1 = 0.0f;

// Fungsi untuk menggambar kubus 3D transparan
void drawCube() {
    glPushMatrix();
    
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    glColor4f(0.0f, 0.0f, 1.0f, 0.5f); // Biru transparan
    
    glutSolidCube(1.0);
    
    glDisable(GL_BLEND);
    
    glPopMatrix();
}

// Fungsi tampilan
void display() {
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    glLoadIdentity();
    
    glTranslatef(0.0f, 0.0f, -5.0f);
    glRotatef(rotAngle, 0.0f, 1.0f, 0.0f);
    glRotatef(rotAngle1, 1.0f, 0.0f, 0.0f);
    
    drawCube();
    
    glutSwapBuffers();
}

// Fungsi keyboard untuk kontrol rotasi
void keyboard(unsigned char key, int x, int y) {
    switch (key) {
        case 'a': rotAngle += 5; break;
        case 'd': rotAngle -= 5; break;
        case 'w': rotAngle1 += 5; break;
        case 's': rotAngle1 -= 5; break;
        case 'q': exit(0); break;
    }
    glutPostRedisplay();
}

// Inisialisasi OpenGL
void init() {
    glEnable(GL_DEPTH_TEST);
    glClearColor(0.0f, 0.0f, 0.0f, 1.0f); // Latar belakang hitam
    
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluPerspective(60, 1, 1, 1000);
    
    glMatrixMode(GL_MODELVIEW);
}

int main(int argc, char** argv) {
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
    glutInitWindowSize(800, 600);
    glutCreateWindow("Kubus 3D Transparan");
    
    init();
    
    glutDisplayFunc(display);
    glutKeyboardFunc(keyboard);
    
    glutMainLoop();
    return 0;
}

