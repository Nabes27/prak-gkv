
#include <GL/glut.h>
#include <stdlib.h>

// Variabel rotasi utama
double rotAngle = 90;
double rotAngle1 = 0;

// Variabel rotasi untuk tiap bagian kapal
float rotFront = 0.0f;
float rotMiddle = 0.0f;
float rotBack = 0.0f;
float rotWingFront = 0.0f;
float rotWingBack = 0.0f;
float rotTower = 0.0f;

// Variabel warna untuk tiap bagian (R, G, B)
float colorFront[3] = {1.0f, 1.0f, 1.0f};  // Putih
float colorMiddle[3] = {0.5f, 0.5f, 0.5f}; // Abu-abu
float colorBack[3] = {0.3f, 0.3f, 0.3f};   // Abu tua
float colorWingFront[3] = {1.0f, 0.0f, 0.0f}; // Merah
float colorWingBack[3] = {0.7f, 0.0f, 0.0f}; // Merah tua
float colorTower[3] = {0.3f, 0.3f, 0.3f};  
float colorWater[3] = {0.0f, 0.0f, 1.0f};  

// Fungsi untuk menggambar kapal selam
void drawSubmarine() {
    glPushMatrix();
    
    // **1. Bagian Depan (Bola)**
    glPushMatrix();
    glColor3fv(colorFront);
    glTranslatef(0.0, 0.0, 1.9);
    glRotatef(rotFront, 0, 1, 0);
    glutSolidSphere(0.4, 20, 20);
    glPopMatrix();

    // **2. Badan Tengah (Tabung Besar)**
    glPushMatrix();
    glColor3fv(colorMiddle);
    glTranslatef(0.0, 0.0, 0.2);
    glRotatef(rotMiddle, 0, 1, 0);
    GLUquadric *cylinder = gluNewQuadric();
    gluQuadricNormals(cylinder, GLU_SMOOTH);
    gluCylinder(cylinder, 0.4, 0.4, 1.7, 20, 20);
    glPopMatrix();

    // **3. Bagian Belakang (Tabung Kecil)**
    glPushMatrix();
    glColor3fv(colorBack);
    glTranslatef(0.0, 0.0, 0.2);
    glRotatef(180, 0, 180, 0);
    gluCylinder(cylinder, 0.4, 0.2, 1.0, 20, 20);
    glPopMatrix();

    // **4. Menara**
    glPushMatrix();
    glColor3fv(colorTower);
    glTranslatef(0.0, 0.4, 1.4);
    glRotatef(rotTower, 0, 1, 0);
    glScalef(0.2, 0.5, 0.2);
    glutSolidCube(1);
    glPopMatrix();

    glPushMatrix();
    glColor3fv(colorTower);
    glTranslatef(0.0, 0.65, 1.4);
    glScalef(0.5, 0.1, 0.2);
    glutSolidCube(1);
    glPopMatrix();

    // **5. Sayap Depan**
    glPushMatrix();
    glColor3fv(colorWingFront);
    glTranslatef(0.0, 0.0, 1.5);
    glRotatef(rotWingFront, 1, 0, 0);
    glScalef(1.5, 0.1, 0.3);
    glutSolidCube(1);
    glPopMatrix();

    // **6. Sayap Belakang**
    glPushMatrix();
    glColor3fv(colorWingBack);
    glTranslatef(0.0, 0.0, -1.0);
    glRotatef(rotWingBack, 1, 0, 0);
    glScalef(0.7, 0.7, 0.3);
    glutSolidCube(1);
    glPopMatrix();
    
    // **7. Air laut (hanya sisi dalam)**
    glPushMatrix();
    glColor4f(0.0f, 0.0f, 1.0f, 0.5f); // Warna biru transparan
    glEnable(GL_CULL_FACE);
    glCullFace(GL_FRONT); // Render hanya sisi dalam
    glTranslatef(0.0, -0.5, 0.5);
    glScalef(1.5, 1.5, 4.0);
    glutSolidCube(1);
    glCullFace(GL_BACK); // Kembalikan ke normal
    glDisable(GL_CULL_FACE);
    glPopMatrix();


    glPopMatrix();
}

// Fungsi untuk mengedit rotasi tiap bagian
void rotatePart(int part, float angle) {
    switch (part) {
        case 1: rotFront += angle; break;
        case 2: rotMiddle += angle; break;
        case 3: rotBack += angle; break;
        case 4: rotWingFront += angle; break;
        case 5: rotWingBack += angle; break;
        case 6: rotTower += angle; break;
    }
    glutPostRedisplay();
}

// Fungsi untuk mengubah warna bagian tertentu
void changeColor(int part, float r, float g, float b) {
    switch (part) {
        case 1: colorFront[0] = r; colorFront[1] = g; colorFront[2] = b; break;
        case 2: colorMiddle[0] = r; colorMiddle[1] = g; colorMiddle[2] = b; break;
        case 3: colorBack[0] = r; colorBack[1] = g; colorBack[2] = b; break;
        case 4: colorWingFront[0] = r; colorWingFront[1] = g; colorWingFront[2] = b; break;
        case 5: colorWingBack[0] = r; colorWingBack[1] = g; colorWingBack[2] = b; break;
        case 6: colorTower[0] = r; colorTower[1] = g; colorTower[2] = b; break;
    }
    glutPostRedisplay();
}

// Inisialisasi OpenGL
void init() {
    glEnable(GL_DEPTH_TEST);
    glEnable(GL_CULL_FACE);
    glClearColor(0, 0, 0, 1);
    glClearDepth(1.0);
    
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluPerspective(60, 1, 1, 1000);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
    gluLookAt(0.0, 0.0, 5.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0);
}

// Fungsi display
void display() {
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    glPushMatrix();

    glRotated(rotAngle, 0, 1, 0);
    glRotated(rotAngle1, 1, 0, 0);
    
    drawSubmarine();

    glPopMatrix();
    glFlush();
    glutSwapBuffers();
}

// Fungsi keyboard untuk mengontrol rotasi & warna
void keyboard(unsigned char key, int x, int y) {
    switch (key) {
        case 'a': rotAngle += 5; break;
        case 'd': rotAngle -= 5; break;
        case 'w': rotAngle1 += 5; break;
        case 's': rotAngle1 -= 5; break;
        case 'q': exit(0); break;

        // Kontrol rotasi tiap bagian
        case '1': rotatePart(1, 5); break;
        case '2': rotatePart(2, 5); break;
        case '3': rotatePart(3, 5); break;
        case '4': rotatePart(4, 5); break;
        case '5': rotatePart(5, 5); break;
        case '6': rotatePart(6, 5); break;

        // Kontrol warna tiap bagian (ubah jadi hijau)
        case 'z': changeColor(1, 0, 1, 0); break; 
        case 'x': changeColor(2, 0, 1, 0); break;
        case 'c': changeColor(3, 0, 1, 0); break;
        case 'v': changeColor(4, 0, 1, 0); break;
        case 'b': changeColor(5, 0, 1, 0); break;
        case 'n': changeColor(6, 0, 1, 0); break;
    }
    glutPostRedisplay();
}

int main(int argc, char **argv) {
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
    glutCreateWindow("Submarine");
    init();
    glutDisplayFunc(display);
    glutKeyboardFunc(keyboard);
    glutMainLoop();
    return 0;
}
