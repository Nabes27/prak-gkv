#include <GL/glut.h>
#include <cmath>

void display() {
    glClear(GL_COLOR_BUFFER_BIT);
    glLoadIdentity();
    
    glColor3f(1.0, 0.0, 1.0); // Warna ungu
    float radius = 0.3f;
    int num_segments = 100; // Jumlah segmen untuk membentuk lingkaran
    
    glBegin(GL_TRIANGLE_FAN);
    glVertex2f(0.0f, 0.0f); // Titik tengah lingkaran
    for (int i = 0; i <= num_segments; i++) {
        float theta = 2.0f * M_PI * float(i) / float(num_segments);
        float x = radius * cosf(theta);
        float y = radius * sinf(theta);
        glVertex2f(x, y);
    }
    glEnd();
    
    glFlush();
}

void init() {
    glClearColor(0.5, 0.8, 1.0, 1.0); // Warna latar belakang (biru muda)
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluOrtho2D(-1.0, 1.0, -1.0, 1.0); // Area tampilan ortho 2D
}

int main(int argc, char **argv) {
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB);
    glutInitWindowSize(800, 600);
    glutCreateWindow("Lingkaran");
    
    init();
    glutDisplayFunc(display);
    glutMainLoop();
    
    return 0;
}

