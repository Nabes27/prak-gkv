#include "imageloader.h"
#include <cstdio>
#include <cstdlib>

Image* ImageLoader::loadBMP(const char* filename) {
    FILE* file = fopen(filename, "rb");
    if (!file) {
        printf("Error: Could not open %s\n", filename);
        return nullptr;
    }

    unsigned char header[54];
    fread(header, sizeof(unsigned char), 54, file);
    int width = *(int*)&header[18];
    int height = *(int*)&header[22];
    int size = 3 * width * height;

    unsigned char* data = new unsigned char[size];
    fread(data, sizeof(unsigned char), size, file);
    fclose(file);

    Image* image = new Image();
    image->width = width;
    image->height = height;
    image->pixels = data;
    return image;
}

