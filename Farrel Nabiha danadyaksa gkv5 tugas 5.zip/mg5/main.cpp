#include <GL/glut.h>
#include "imageloader.h"

GLuint texture;

void loadTexture() {
    Image* image = ImageLoader::loadBMP("texture.bmp");
    if (!image) return;

    glGenTextures(1, &texture);
    glBindTexture(GL_TEXTURE_2D, texture);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, image->width, image->height, 0, GL_BGR, GL_UNSIGNED_BYTE, image->pixels);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

    delete[] image->pixels;
    delete image;
}

void display() {
    glClear(GL_COLOR_BUFFER_BIT);
    glEnable(GL_TEXTURE_2D);
    glBindTexture(GL_TEXTURE_2D, texture);

    glBegin(GL_QUADS);
        glTexCoord2f(0, 0); glVertex2f(-0.5, -0.5);
        glTexCoord2f(1, 0); glVertex2f( 0.5, -0.5);
        glTexCoord2f(1, 1); glVertex2f( 0.5,  0.5);
        glTexCoord2f(0, 1); glVertex2f(-0.5,  0.5);
    glEnd();

    glDisable(GL_TEXTURE_2D);
    glutSwapBuffers();
}

void init() {
    glClearColor(0.0, 0.0, 0.0, 1.0);
    loadTexture();
}

int main(int argc, char** argv) {
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB);
    glutInitWindowSize(500, 500);
    glutCreateWindow("Texture Mapping");
    
    init();
    glutDisplayFunc(display);
    glutMainLoop();
    return 0;
}

