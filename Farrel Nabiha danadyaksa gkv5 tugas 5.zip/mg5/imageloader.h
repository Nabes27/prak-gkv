#ifndef IMAGELOADER_H
#define IMAGELOADER_H

#include <GL/glut.h>

struct Image {
    int width, height;
    unsigned char* pixels;
};

class ImageLoader {
public:
    static Image* loadBMP(const char* filename);
};

#endif

